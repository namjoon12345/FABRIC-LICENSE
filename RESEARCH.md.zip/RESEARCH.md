# Investigación de FabricLicense

## Proyecto de Innovación
Estamos llevando a cabo investigaciones sobre la integración de blockchain en la gestión de licencias y sus beneficios en el mercado.
